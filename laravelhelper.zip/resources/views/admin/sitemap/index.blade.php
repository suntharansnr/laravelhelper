<?php echo '<?xml version="1.0" encoding="UTF-8"?>'; ?>

<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
    <sitemap>
        <loc>https://www.nithyasactivequeen.com/sitemap.xml/posts</loc>
    </sitemap>
    <sitemap>
        <loc>https://www.nithyasactivequeen.com/sitemap.xml/categories</loc>
    </sitemap>
    <sitemap>
        <loc>https://www.nithyasactivequeen.com/sitemap.xml/site_url</loc>
    </sitemap>
    <sitemap>
        <loc>https://www.nithyasactivequeen.com/sitemap.xml/users</loc>
    </sitemap>
</sitemapindex>