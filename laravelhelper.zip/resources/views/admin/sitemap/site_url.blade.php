<?php echo '<?xml version="1.0" encoding="UTF-8"?>'; ?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.sitemaps.org/schemas/sitemap/0.9 http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd">
<!--  created by Raj varman -->
<url>
<loc>https://www.nithyasactivequeen.com/</loc>
<lastmod>2020-08-02T06:58:45+00:00</lastmod>
<priority>1.00</priority>
</url>
<url>
<loc>https://www.nithyasactivequeen.com/about</loc>
<lastmod>2020-08-02T06:58:45+00:00</lastmod>
<priority>0.80</priority>
</url>
<url>
<loc>https://www.nithyasactivequeen.com/service</loc>
<lastmod>2020-08-02T06:58:45+00:00</lastmod>
<priority>0.80</priority>
</url>
<url>
<loc>https://www.nithyasactivequeen.com/blog</loc>
<lastmod>2020-08-02T06:58:45+00:00</lastmod>
<priority>0.80</priority>
</url>
<url>
<loc>https://www.nithyasactivequeen.com/contact</loc>
<lastmod>2020-08-02T06:58:45+00:00</lastmod>
<priority>0.80</priority>
</url>
</urlset>

