<header id="scrolltops">
  <div class="container">
  <nav class="navbar navbar-expand-lg shrink shadow fixed-top" id="banner">
       <!-- Brand -->
      <a class="navbar-brand" href="{{route('radios')}}"><img src="{{asset($theme->logo)}}" alt="" class="img-fluid"></a>
      <!-- Toggler/collapsibe Button -->
      <button class="navbar-toggler custom-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
      <span class="navbar-toggler-icon"></span>
      </button>

      <!-- Navbar links -->
      <div class="collapse navbar-collapse justify-content-center" id="collapsibleNavbar">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link">Learn laravel from begginer level to master level on laravel.xyz</a>
        </li>
      </ul>
      </div>
  </nav>
</header>
